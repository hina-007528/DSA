#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
};

class StackLinkedList {
private:
    Node* top;

public:
    StackLinkedList() {
        top = nullptr;
    }

    bool is_empty() {
        return top == nullptr;
    }

    
    bool is_full() {
        return false;
    }

    void push(int x) {
        Node* newNode = new Node();
        newNode->data = x;
        newNode->next = top;
        top = newNode;
    }

    void pop() {
        if (is_empty()) {
            cout << "Stack Underflow\n";
            return;
        }
        Node* temp = top;
        top = top->next;
        delete temp;
    }

    int top_element() {
        if (is_empty()) {
            cout << "Stack is Empty\n";
            return -1;
        }
        return top->data;
    }
};

int main() {
    StackLinkedList s;
    s.push(100);
    s.push(200);
    cout << "Top element: " << s.top_element() << endl;
    s.pop();
    cout << "Top element after pop: " << s.top_element() << endl;
    return 0;
}
