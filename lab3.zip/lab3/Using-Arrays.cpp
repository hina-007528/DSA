#include <iostream>
using namespace std;

#define MAX 1000  

class StackArray {
private:
    int top;
    int arr[MAX];

public:
    StackArray() {
        top = -1;
    }

    bool is_empty() {
        return top == -1;
    }

    bool is_full() {
        return top == MAX - 1;
    }

    void push(int x) {
        if (is_full()) {
            cout << "Stack Overflow\n";
            return;
        }
        arr[++top] = x;
    }

    void pop() {
        if (is_empty()) {
            cout << "Stack Underflow\n";
            return;
        }
        top--;
    }

    int top_element() {
        if (is_empty()) {
            cout << "Stack is Empty\n";
            return -1;
        }
        return arr[top];
    }
};

int main() {
    StackArray s;
    s.push(10);
    s.push(20);
    cout << "Top element: " << s.top_element() << endl;
    s.pop();
    cout << "Top element after pop: " << s.top_element() << endl;
    return 0;
}
