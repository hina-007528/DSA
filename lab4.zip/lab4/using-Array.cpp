#include <iostream>
using namespace std;

#define MAX 1000 

class QueueArray {
private:
    int frontIndex, rearIndex;
    int arr[MAX];

public:
    QueueArray() {
        frontIndex = -1;
        rearIndex = -1;
    }

    bool is_empty() {
        return frontIndex == -1 || frontIndex > rearIndex;
    }

    bool is_full() {
        return rearIndex == MAX - 1;
    }

    void enqueue(int x) {
        if (is_full()) {
            cout << "Queue Overflow\n";
            return;
        }
        if (is_empty()) {
            frontIndex = 0;
        }
        arr[++rearIndex] = x;
    }

    void dequeue() {
        if (is_empty()) {
            cout << "Queue Underflow\n";
            return;
        }
        frontIndex++;
    }

    int front() {
        if (is_empty()) {
            cout << "Queue is Empty\n";
            return -1;
        }
        return arr[frontIndex];
    }

    int rear() {
        if (is_empty()) {
            cout << "Queue is Empty\n";
            return -1;
        }
        return arr[rearIndex];
    }
};

int main() {
    QueueArray q;
    q.enqueue(10);
    q.enqueue(20);
    cout << "Front: " << q.front() << endl;
    cout << "Rear: " << q.rear() << endl;
    q.dequeue();
    cout << "Front after dequeue: " << q.front() << endl;
    return 0;
}
