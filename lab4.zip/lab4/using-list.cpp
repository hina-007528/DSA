#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
};

class QueueLinkedList {
private:
    Node* frontNode;
    Node* rearNode;

public:
    QueueLinkedList() {
        frontNode = rearNode = nullptr;
    }

    bool is_empty() {
        return frontNode == nullptr;
    }

    bool is_full() {
        return false;
    }

    void enqueue(int x) {
        Node* newNode = new Node();
        newNode->data = x;
        newNode->next = nullptr;
        if (rearNode == nullptr) {
            frontNode = rearNode = newNode;
        } else {
            rearNode->next = newNode;
            rearNode = newNode;
        }
    }

    void dequeue() {
        if (is_empty()) {
            cout << "Queue Underflow\n";
            return;
        }
        Node* temp = frontNode;
        frontNode = frontNode->next;
        if (frontNode == nullptr) {
            rearNode = nullptr;
        }
        delete temp;
    }

    int front() {
        if (is_empty()) {
            cout << "Queue is Empty\n";
            return -1;
        }
        return frontNode->data;
    }

    int rear() {
        if (is_empty()) {
            cout << "Queue is Empty\n";
            return -1;
        }
        return rearNode->data;
    }
};

int main() {
    QueueLinkedList q;
    q.enqueue(100);
    q.enqueue(200);
    cout << "Front: " << q.front() << endl;
    cout << "Rear: " << q.rear() << endl;
    q.dequeue();
    cout << "Front after dequeue: " << q.front() << endl;
    return 0;
}
