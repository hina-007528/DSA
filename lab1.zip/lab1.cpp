#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = nullptr;
    }
};

class SinglyLinkedList {
private:
    Node* head;

public:
    SinglyLinkedList() {
        head = nullptr;
    }


    void addAtStart(int data) {
        Node* newNode = new Node(data);
        newNode->next = head;
        head = newNode;
    }

   
    void addAtIndex(int index, int data) {
        if (index == 0) {
            addAtStart(data);
            return;
        }

        Node* newNode = new Node(data);
        Node* current = head;
        int count = 0;

        while (current != nullptr && count < index - 1) {
            current = current->next;
            count++;
        }

        if (current == nullptr) {
            cout << "Index out of bounds.\n";
            return;
        }

        newNode->next = current->next;
        current->next = newNode;
    }

  
    void addAtEnd(int data) {
        Node* newNode = new Node(data);
        if (head == nullptr) {
            head = newNode;
            return;
        }

        Node* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }

        current->next = newNode;
    }

    void removeHead() {
        if (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

   
    void removeAtIndex(int index) {
        if (index == 0) {
            removeHead();
            return;
        }

        Node* current = head;
        int count = 0;

        while (current != nullptr && current->next != nullptr && count < index - 1) {
            current = current->next;
            count++;
        }

        if (current == nullptr || current->next == nullptr) {
            cout << "Index out of bounds.\n";
            return;
        }

        Node* temp = current->next;
        current->next = temp->next;
        delete temp;
    }

 
    void removeLast() {
        if (head == nullptr) return;

        if (head->next == nullptr) {
            delete head;
            head = nullptr;
            return;
        }

        Node* current = head;
        while (current->next->next != nullptr) {
            current = current->next;
        }

        delete current->next;
        current->next = nullptr;
    }

   
    Node* find(int data) {
        Node* current = head;
        while (current != nullptr) {
            if (current->data == data)
                return current;
            current = current->next;
        }
        return nullptr;
    }


    int get(int index) {
        Node* current = head;
        int count = 0;

        while (current != nullptr) {
            if (count == index)
                return current->data;
            current = current->next;
            count++;
        }

        cout << "Index out of bounds.\n";
        return -1;
    }

    
    void start() {
        Node* current = head;
        if (current == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        while (current != nullptr) {
            cout << current->data;
            if (current->next != nullptr)
                cout << " -> ";
            current = current->next;
        }
        cout << endl;
    }
};int main() {
    SinglyLinkedList list;

    list.addAtStart(10);
    list.addAtEnd(20);
    list.addAtIndex(1, 15);
    list.start(); 

    list.removeHead();
    list.start(); 

    list.removeAtIndex(1);
    list.start(); 

    list.addAtEnd(25);
    list.addAtEnd(30);
    list.removeLast();
    list.start(); 

    Node* found = list.find(25);
    if (found)
        cout << "Found: " << found->data << endl;
    else
        cout << "Not found\n";

    cout << "Element at index 1: " << list.get(1) << endl; 
    return 0;
}


